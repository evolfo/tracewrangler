/* TraceWrangler - Network Capture File Toolkit
   By Jasper Bongertz <jasper@packet-foo.com>
   Copyright 2016 Jasper Bongertz
 
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
 
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
 
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

CREATE TABLE "rdb_counters" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE , "name" VARCHAR NOT NULL  UNIQUE , "counter" INTEGER NOT NULL  DEFAULT 0);
CREATE TABLE "rdb_ethernet" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE , "originalmac" VARCHAR NOT NULL UNIQUE , "replacementmac" VARCHAR NOT NULL, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_vlanids" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE , "originalvlanid" INTEGER NOT NULL UNIQUE , "replacementvlanid" INTEGER NOT NULL, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_guids" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE , "OldGUID" CHAR UNIQUE , "NewGUID" CHAR NOT NULL UNIQUE, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_ipv4" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE , "originalip" INTEGER NOT NULL UNIQUE , "replacementip" INTEGER NOT NULL, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_ipv6" ("id" INTEGER PRIMARY KEY NOT NULL ,"originalip" VARCHAR NOT NULL UNIQUE,"replacementip" VARCHAR NOT NULL, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_nameresolution" ("id" INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL  UNIQUE , "originalfqdn" VARCHAR NOT NULL UNIQUE, "replacementfqdn" VARCHAR);
CREATE TABLE "rdb_tcpports" ("id" INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL  UNIQUE , "originalip" VARCHAR NOT NULL, "originalport" INTEGER NOT NULL, "replacementip" VARCHAR, "replacementport" INTEGER NOT NULL, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_udpports" ("id" INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL  UNIQUE , "originalip" VARCHAR NOT NULL, "originalport" INTEGER NOT NULL , "replacementip" VARCHAR, "replacementport" INTEGER NOT NULL, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_meta" ("id" INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL  UNIQUE , "name" CHAR, "value" CHAR);
CREATE TABLE "rdb_pcapngstrings" ("id" INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL  UNIQUE, "origin" INTEGER DEFAULT 0, "original" CHAR NOT NULL UNIQUE, "replacement" CHAR, "scope" INTEGER DEFAULT 0);
CREATE TABLE "rdb_ipidentification" ("id" INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL  UNIQUE , "originalid" INTEGER NOT NULL UNIQUE, "replacementid" INTEGER, "sourceip" VARCHAR, "destinationip" VARCHAR);
CREATE TABLE "rdb_ssids" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, "original" VARCHAR UNIQUE, "replacement" VARCHAR);
CREATE TABLE "rdb_genericintegers" ("id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, "origin" INTEGER DEFAULT 0, "original" BIGINT UNIQUE, "replacement" BIGINT);
CREATE UNIQUE INDEX "rdb_index_ipv4address" ON "rdb_ipv4" ("originalip" ASC);
CREATE UNIQUE INDEX "rdb_index_ipv6address" ON "rdb_ipv6" ("originalip" ASC);
CREATE UNIQUE INDEX "rdb_index_macaddress" ON "rdb_ethernet" ("originalmac" ASC);
CREATE UNIQUE INDEX "rdb_index_vlanid" ON "rdb_vlanids" ("originalvlanid" ASC);
CREATE UNIQUE INDEX "rdb_index_tcpport" ON "rdb_tcpports" ("originalip" ASC, "originalport" ASC);
CREATE UNIQUE INDEX "rdb_index_udpport" ON "rdb_udpports" ("originalip" ASC, "originalport" ASC);
CREATE UNIQUE INDEX "rdb_index_fqdn" ON "rdb_nameresolution" ("originalfqdn" ASC);
CREATE UNIQUE INDEX "rdb_index_ssid" ON "rdb_ssids" ("original" ASC);
CREATE UNIQUE INDEX "rdb_index_genericinteger" ON "rdb_genericintegers" ("origin" ASC, "original" ASC);